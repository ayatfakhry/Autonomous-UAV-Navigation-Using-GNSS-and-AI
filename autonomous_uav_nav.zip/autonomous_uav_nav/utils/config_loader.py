"""
=============================================================================
utils/config_loader.py  –  Hierarchical YAML Configuration System
=============================================================================
Loads, validates, and provides typed access to the master config.yaml.
Supports environment variable overrides and runtime patching.
=============================================================================
"""

from __future__ import annotations

import os
import copy
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import yaml


# ──────────────────────────────────────────────────────────────────────────────
# Typed sub-configs (dataclasses for IDE autocomplete & validation)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class UAVPhysics:
    mass_kg: float = 1.5
    arm_length_m: float = 0.23
    max_thrust_N: float = 25.0
    max_velocity_ms: float = 15.0
    max_acceleration_ms2: float = 8.0
    battery_capacity_mAh: float = 5000.0
    hover_current_A: float = 8.5
    drag_coefficient: float = 0.1
    Ixx: float = 0.0123
    Iyy: float = 0.0123
    Izz: float = 0.0246


@dataclass
class SensorConfig:
    gnss_noise_m: float = 0.5
    imu_accel_noise: float = 0.01
    imu_gyro_noise: float = 0.001
    lidar_range_m: float = 100.0
    camera_fps: int = 30
    barometer_noise_m: float = 0.1


@dataclass
class RLConfig:
    algorithm: str = "SAC"
    learning_rate: float = 3e-4
    batch_size: int = 256
    buffer_size: int = 1_000_000
    gamma: float = 0.99
    total_timesteps: int = 2_000_000


@dataclass
class UAVConfig:
    """Top-level typed configuration object."""
    raw: Dict[str, Any] = field(default_factory=dict)
    physics: UAVPhysics = field(default_factory=UAVPhysics)
    sensors: SensorConfig = field(default_factory=SensorConfig)
    rl: RLConfig = field(default_factory=RLConfig)

    def get(self, key: str, default: Any = None) -> Any:
        """Dot-separated key access: 'environment.wind.base_speed_ms'."""
        keys = key.split(".")
        val = self.raw
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val


# ──────────────────────────────────────────────────────────────────────────────
# Main Loader
# ──────────────────────────────────────────────────────────────────────────────

class ConfigLoader:
    """
    Loads YAML config with:
      - Environment variable overrides (UAV_<SECTION>_<KEY>=value)
      - Deep-merge of multiple files
      - Runtime patch support
    """

    _DEFAULT_PATH = Path(__file__).parent.parent / "configs" / "config.yaml"

    def __init__(self, config_path: Optional[str] = None):
        self._path = Path(config_path) if config_path else self._DEFAULT_PATH
        self._raw: Dict[str, Any] = {}
        self._load()
        self._apply_env_overrides()

    # ── Private ───────────────────────────────────────────────────────────────

    def _load(self) -> None:
        if not self._path.exists():
            raise FileNotFoundError(f"Config not found: {self._path}")
        with open(self._path, "r") as f:
            self._raw = yaml.safe_load(f) or {}

    def _apply_env_overrides(self) -> None:
        """Override any config key via UAV_SECTION_KEY=value env vars."""
        prefix = "UAV_"
        for env_key, env_val in os.environ.items():
            if not env_key.startswith(prefix):
                continue
            parts = env_key[len(prefix):].lower().split("_", 1)
            if len(parts) == 2:
                section, key = parts
                if section in self._raw and isinstance(self._raw[section], dict):
                    # Attempt type coercion
                    orig = self._raw[section].get(key)
                    self._raw[section][key] = self._coerce(env_val, type(orig))

    @staticmethod
    def _coerce(val: str, typ: type) -> Any:
        try:
            if typ == bool:
                return val.lower() in ("1", "true", "yes")
            if typ == int:
                return int(val)
            if typ == float:
                return float(val)
        except (ValueError, TypeError):
            pass
        return val

    def _deep_get(self, keys: list, data: dict) -> Any:
        for k in keys:
            if isinstance(data, dict) and k in data:
                data = data[k]
            else:
                return None
        return data

    # ── Public API ────────────────────────────────────────────────────────────

    def get(self, dot_key: str, default: Any = None) -> Any:
        """Access config via dot notation: 'sensors.gnss.update_rate_hz'."""
        return self._deep_get(dot_key.split("."), self._raw) or default

    def patch(self, dot_key: str, value: Any) -> None:
        """Dynamically override a config value at runtime."""
        keys = dot_key.split(".")
        data = self._raw
        for k in keys[:-1]:
            data = data.setdefault(k, {})
        data[keys[-1]] = value

    def as_uav_config(self) -> UAVConfig:
        """Return a typed UAVConfig object from raw YAML."""
        uav_raw = self._raw.get("uav", {})
        inertia = uav_raw.get("inertia", {})
        physics = UAVPhysics(
            mass_kg=uav_raw.get("mass_kg", 1.5),
            arm_length_m=uav_raw.get("arm_length_m", 0.23),
            max_thrust_N=uav_raw.get("max_thrust_N", 25.0),
            max_velocity_ms=uav_raw.get("max_velocity_ms", 15.0),
            max_acceleration_ms2=uav_raw.get("max_acceleration_ms2", 8.0),
            battery_capacity_mAh=uav_raw.get("battery_capacity_mAh", 5000.0),
            hover_current_A=uav_raw.get("hover_current_A", 8.5),
            drag_coefficient=uav_raw.get("drag_coefficient", 0.1),
            Ixx=inertia.get("Ixx", 0.0123),
            Iyy=inertia.get("Iyy", 0.0123),
            Izz=inertia.get("Izz", 0.0246),
        )
        sensors_raw = self._raw.get("sensors", {})
        sensors = SensorConfig(
            gnss_noise_m=sensors_raw.get("gnss", {}).get("position_noise_m", 0.5),
            imu_accel_noise=sensors_raw.get("imu", {}).get("accel_noise_ms2", 0.01),
            imu_gyro_noise=sensors_raw.get("imu", {}).get("gyro_noise_rads", 0.001),
            lidar_range_m=sensors_raw.get("lidar", {}).get("range_m", 100.0),
            camera_fps=sensors_raw.get("camera", {}).get("update_rate_hz", 30),
            barometer_noise_m=sensors_raw.get("barometer", {}).get("altitude_noise_m", 0.1),
        )
        rl_raw = self._raw.get("rl", {})
        rl = RLConfig(
            algorithm=rl_raw.get("algorithm", "SAC"),
            learning_rate=rl_raw.get("learning_rate", 3e-4),
            batch_size=rl_raw.get("batch_size", 256),
            buffer_size=rl_raw.get("buffer_size", 1_000_000),
            gamma=rl_raw.get("gamma", 0.99),
            total_timesteps=rl_raw.get("training", {}).get("total_timesteps", 2_000_000),
        )
        return UAVConfig(raw=copy.deepcopy(self._raw), physics=physics, sensors=sensors, rl=rl)

    @property
    def raw(self) -> Dict[str, Any]:
        return copy.deepcopy(self._raw)

    def __repr__(self) -> str:
        return f"ConfigLoader(path={self._path}, sections={list(self._raw.keys())})"
