"""
Autonomous UAV Navigation System
=================================
Research-grade autonomous drone navigation using AI, sensor fusion,
reinforcement learning, and computer vision.

Modules:
    agents      – RL agents (SAC/PPO/DQN) + swarm intelligence
    envs        – Gymnasium simulation environment
    sensors     – Sensor models + EKF/UKF fusion
    navigation  – A*, RRT*, cascaded PID controller
    vision      – YOLOv8, tracking, landing zone detection
    dashboard   – Real-time Plotly Dash mission control
    evaluation  – Metrics, visualization, benchmarking
    utils       – Config, logger, math, recording

Quick Start:
    python scripts/run_simulation.py
    python scripts/train.py --algo SAC
    python scripts/evaluate.py --model models/final_model
"""

__version__ = "1.0.0"
__author__  = "UAV Research Team"
__license__ = "MIT"
