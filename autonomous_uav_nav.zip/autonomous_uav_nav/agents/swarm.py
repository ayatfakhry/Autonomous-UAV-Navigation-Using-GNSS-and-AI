"""
=============================================================================
agents/swarm.py  –  Multi-UAV Swarm Intelligence
=============================================================================
Implements:
  - Reynolds flocking (separation, cohesion, alignment)
  - Formation flight (V, line, circle, grid)
  - Cooperative path planning
  - Inter-drone collision avoidance
  - Consensus-based goal assignment
=============================================================================
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from utils.math_utils import normalize_vector, clamp
from utils.logger import get_logger

log = get_logger("SWARM")


# ──────────────────────────────────────────────────────────────────────────────
# Drone Agent (lightweight state for swarm)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class DroneAgent:
    agent_id:    int
    position:    np.ndarray = field(default_factory=lambda: np.zeros(3))
    velocity:    np.ndarray = field(default_factory=lambda: np.zeros(3))
    heading:     float = 0.0
    battery_pct: float = 100.0
    is_leader:   bool  = False
    goal:        Optional[np.ndarray] = None
    comm_range:  float = 50.0
    status:      str   = "active"   # active | hover | rtb | failed

    def distance_to(self, other: "DroneAgent") -> float:
        return float(np.linalg.norm(self.position - other.position))

    def can_communicate(self, other: "DroneAgent") -> bool:
        return self.distance_to(other) <= self.comm_range


# ──────────────────────────────────────────────────────────────────────────────
# Reynolds Flocking Rules
# ──────────────────────────────────────────────────────────────────────────────

class ReynoldsFlocking:
    """
    Classic Boids flocking algorithm extended for 3D UAV swarms.
    Rules: separation + cohesion + alignment + goal-seeking
    """

    def __init__(self, config: dict):
        swarm = config.get("swarm", {})
        self.w_sep   = swarm.get("separation_weight", 0.5)
        self.w_coh   = swarm.get("cohesion_weight", 0.3)
        self.w_ali   = swarm.get("alignment_weight", 0.2)
        self.w_goal  = 1.0
        self.sep_dist= swarm.get("separation_distance_m", 8.0)
        self.max_spd = 10.0

    def compute_velocity(
        self,
        agent:   DroneAgent,
        neighbors: List[DroneAgent],
        goal_pos:  np.ndarray,
    ) -> np.ndarray:

        if not neighbors:
            # Head straight to goal
            to_goal = goal_pos - agent.position
            return normalize_vector(to_goal) * self.max_spd * 0.5

        # ── Separation ────────────────────────────────────────────────
        sep = np.zeros(3)
        for n in neighbors:
            diff = agent.position - n.position
            dist = np.linalg.norm(diff)
            if dist < self.sep_dist and dist > 1e-6:
                sep += diff / (dist ** 2)

        # ── Cohesion ─────────────────────────────────────────────────
        center = np.mean([n.position for n in neighbors], axis=0)
        coh = center - agent.position

        # ── Alignment ────────────────────────────────────────────────
        avg_vel = np.mean([n.velocity for n in neighbors], axis=0)
        ali = avg_vel - agent.velocity

        # ── Goal seeking ─────────────────────────────────────────────
        to_goal = goal_pos - agent.position
        dist_goal = np.linalg.norm(to_goal)
        goal = to_goal / max(dist_goal, 1e-6)

        # Combine
        steering = (
            self.w_sep  * normalize_vector(sep)  +
            self.w_coh  * normalize_vector(coh)  +
            self.w_ali  * normalize_vector(ali)  +
            self.w_goal * goal
        )
        speed = min(self.max_spd, dist_goal * 0.5 + 2.0)
        return normalize_vector(steering) * speed


# ──────────────────────────────────────────────────────────────────────────────
# Formation Controller
# ──────────────────────────────────────────────────────────────────────────────

class FormationController:
    """
    Geometric formation controller.
    Computes per-agent offset from leader's position.
    """

    FORMATIONS = {
        "v_formation": None,    # computed dynamically
        "line":        None,
        "circle":      None,
        "grid":        None,
        "diamond":     None,
    }

    def __init__(self, formation: str = "v_formation",
                 separation: float = 8.0):
        self._formation  = formation
        self._separation = separation

    def get_offsets(self, n_agents: int, leader_heading: float) -> List[np.ndarray]:
        """Return list of position offsets for each agent relative to leader."""
        s = self._separation
        ch, sh = math.cos(leader_heading), math.sin(leader_heading)
        fwd  = np.array([ ch,  sh, 0.0])
        side = np.array([-sh,  ch, 0.0])

        offsets = [np.zeros(3)]  # Leader at origin

        if self._formation == "v_formation":
            for i in range(1, n_agents):
                side_sign = 1 if i % 2 == 1 else -1
                rank = (i + 1) // 2
                off = -fwd * s * rank + side * side_sign * s * rank
                off[2] = -0.5 * rank  # Slight altitude stagger
                offsets.append(off)

        elif self._formation == "line":
            for i in range(1, n_agents):
                offsets.append(-fwd * s * i)

        elif self._formation == "circle":
            radius = s * n_agents / (2 * math.pi)
            for i in range(1, n_agents):
                angle = 2 * math.pi * i / n_agents + leader_heading
                offsets.append(np.array([
                    radius * math.cos(angle),
                    radius * math.sin(angle),
                    0.0,
                ]))

        elif self._formation == "grid":
            cols = max(2, int(math.sqrt(n_agents)))
            for i in range(1, n_agents):
                row = i // cols
                col = i % cols
                offsets.append(
                    side * (col - cols/2) * s + (-fwd) * row * s
                )

        # Ensure we have exactly n_agents offsets
        while len(offsets) < n_agents:
            offsets.append(np.array([random.uniform(-5,5), random.uniform(-5,5), 0]))

        return offsets[:n_agents]


# ──────────────────────────────────────────────────────────────────────────────
# Swarm Coordinator
# ──────────────────────────────────────────────────────────────────────────────

class SwarmCoordinator:
    """
    Top-level multi-UAV swarm manager.

    Responsibilities:
      - Agent registration & communication graph
      - Leader election (highest battery / designated)
      - Task assignment (goal → drone mapping)
      - Collision avoidance between drones
      - Failure recovery (dead drone reassignment)
    """

    def __init__(self, config: dict):
        swarm_cfg = config.get("swarm", {})
        self._n_agents   = swarm_cfg.get("num_agents", 5)
        self._formation  = swarm_cfg.get("formation", "v_formation")
        self._comm_range = swarm_cfg.get("communication_range_m", 50.0)
        self._sep_dist   = swarm_cfg.get("separation_distance_m", 8.0)
        self._enabled    = swarm_cfg.get("enabled", False)

        self._agents: Dict[int, DroneAgent] = {}
        self._flocking  = ReynoldsFlocking(config)
        self._formation_ctrl = FormationController(self._formation, self._sep_dist)

        self._global_goal: Optional[np.ndarray] = None
        self._leader_id:   Optional[int]        = None

    # ── Agent Management ──────────────────────────────────────────────────────

    def register_agent(self, agent_id: int, initial_pos: np.ndarray,
                       is_leader: bool = False) -> DroneAgent:
        agent = DroneAgent(
            agent_id=agent_id,
            position=initial_pos.copy(),
            comm_range=self._comm_range,
            is_leader=is_leader,
        )
        self._agents[agent_id] = agent
        if is_leader:
            self._leader_id = agent_id
        log.info(f"Swarm: Agent {agent_id} registered | leader={is_leader}")
        return agent

    def initialize_formation(self, leader_pos: np.ndarray, leader_heading: float = 0.0) -> None:
        """Place all agents in formation around leader_pos."""
        offsets = self._formation_ctrl.get_offsets(len(self._agents), leader_heading)
        for i, (agent_id, agent) in enumerate(sorted(self._agents.items())):
            agent.position = leader_pos + offsets[i]
            agent.heading  = leader_heading
        log.info(f"Formation initialized: {self._formation} | {len(self._agents)} agents")

    # ── Election ──────────────────────────────────────────────────────────────

    def elect_leader(self) -> int:
        """Elect leader by highest battery; tie-break by agent_id."""
        active = {i: a for i, a in self._agents.items() if a.status == "active"}
        if not active:
            return -1
        leader_id = max(active, key=lambda i: (active[i].battery_pct, -i))
        for a in self._agents.values():
            a.is_leader = False
        self._agents[leader_id].is_leader = True
        self._leader_id = leader_id
        return leader_id

    # ── Step ─────────────────────────────────────────────────────────────────

    def step(self, dt: float) -> Dict[int, np.ndarray]:
        """
        Compute velocity commands for all agents.
        Returns {agent_id: velocity_command}.
        """
        if not self._agents:
            return {}

        # Re-elect leader if needed
        if self._leader_id not in self._agents or \
           self._agents[self._leader_id].status != "active":
            self.elect_leader()

        leader = self._agents.get(self._leader_id)
        if leader is None or self._global_goal is None:
            return {aid: np.zeros(3) for aid in self._agents}

        # Formation offsets
        offsets = self._formation_ctrl.get_offsets(
            len(self._agents), leader.heading
        )
        agent_goals = {}
        for i, (agent_id, _) in enumerate(sorted(self._agents.items())):
            off = offsets[i] if i < len(offsets) else np.zeros(3)
            agent_goals[agent_id] = self._global_goal + off

        velocities = {}
        for agent_id, agent in self._agents.items():
            if agent.status != "active":
                velocities[agent_id] = np.zeros(3)
                continue

            # Neighbors in comm range
            neighbors = [
                a for aid, a in self._agents.items()
                if aid != agent_id and agent.can_communicate(a)
            ]

            goal = agent_goals[agent_id]

            # Flocking velocity
            vel = self._flocking.compute_velocity(agent, neighbors, goal)

            # Inter-drone collision avoidance (hard constraint)
            for n in neighbors:
                dist = agent.distance_to(n)
                if dist < self._sep_dist * 0.8:
                    repulse = normalize_vector(agent.position - n.position)
                    vel += repulse * 5.0 * (1.0 - dist / self._sep_dist)

            velocities[agent_id] = vel

            # Update agent state (simple Euler)
            agent.velocity = vel
            agent.position = agent.position + vel * dt
            agent.battery_pct = max(0, agent.battery_pct - 0.002 * dt)
            agent.heading = math.atan2(vel[1], vel[0]) if np.linalg.norm(vel[:2]) > 0.1 else agent.heading

        return velocities

    def set_goal(self, goal: np.ndarray) -> None:
        self._global_goal = goal.copy()

    def get_status(self) -> Dict:
        return {
            "n_agents":    len(self._agents),
            "leader_id":   self._leader_id,
            "formation":   self._formation,
            "goal":        self._global_goal.tolist() if self._global_goal is not None else None,
            "agents": [
                {
                    "id":       a.agent_id,
                    "pos":      a.position.tolist(),
                    "vel":      a.velocity.tolist(),
                    "battery":  a.battery_pct,
                    "status":   a.status,
                    "is_leader":a.is_leader,
                }
                for a in self._agents.values()
            ]
        }
