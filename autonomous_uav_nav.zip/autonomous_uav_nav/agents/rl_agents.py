"""
=============================================================================
agents/rl_agents.py  –  Reinforcement Learning Agent Suite
=============================================================================
Implements:
  1. SAC  (Soft Actor-Critic)           – best for continuous control
  2. PPO  (Proximal Policy Optimization) – stable on-policy training
  3. DQN  (Deep Q-Network)              – discrete action variant
  4. HybridRLController                 – RL + PID blending
  5. TransformerPolicy                  – attention-based navigation policy
=============================================================================
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Type

import numpy as np
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False
    # Minimal stubs so module imports without torch
    class nn:
        class Module:
            def __init__(self): pass
        class Linear:
            def __init__(self, *a, **k): pass
        class Sequential:
            def __init__(self, *a): pass
        class LayerNorm:
            def __init__(self, *a): pass
        class GELU:
            pass
        class LSTM:
            def __init__(self, *a, **k): pass
        class TransformerEncoderLayer:
            def __init__(self, *a, **k): pass
        class TransformerEncoder:
            def __init__(self, *a, **k): pass
        class Parameter:
            def __init__(self, *a): pass
    class torch:
        FloatTensor = None
        @staticmethod
        def no_grad():
            class ctx:
                def __enter__(self): return self
                def __exit__(self, *a): pass
            return ctx()
        @staticmethod
        def cat(tensors, dim=-1): return tensors[0]

from utils.logger import get_logger

log = get_logger("RL")

# ── Optional SB3 import ────────────────────────────────────────────────────────
try:
    from stable_baselines3 import SAC, PPO, DQN
    from stable_baselines3.common.policies import ActorCriticPolicy
    from stable_baselines3.common.torch_layers import BaseFeaturesExtractor
    from stable_baselines3.common.callbacks import (
        EvalCallback, CheckpointCallback, CallbackList
    )
    from stable_baselines3.common.monitor import Monitor
    from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
    _HAS_SB3 = True
except ImportError:
    _HAS_SB3 = False
    log.warning("stable-baselines3 not installed. RL training disabled.")


# ──────────────────────────────────────────────────────────────────────────────
# Custom Neural Network Architectures
# ──────────────────────────────────────────────────────────────────────────────

class UAVFeatureExtractor(nn.Module):
    """
    Custom feature extractor for UAV observations.
    Separates:
      - Navigation features (pos, vel, att, goal)
      - LiDAR features (obstacle proximity)
      - Sensor quality features
    and fuses them via attention.
    """

    def __init__(self, obs_dim: int = 48, features_dim: int = 256):
        super().__init__()
        self.features_dim = features_dim

        # Navigation branch (position, velocity, attitude, goal)
        self.nav_encoder = nn.Sequential(
            nn.Linear(18, 64),
            nn.LayerNorm(64),
            nn.GELU(),
            nn.Linear(64, 128),
            nn.GELU(),
        )

        # Obstacle/LiDAR branch
        self.obs_encoder = nn.Sequential(
            nn.Linear(24, 64),
            nn.LayerNorm(64),
            nn.GELU(),
            nn.Linear(64, 64),
            nn.GELU(),
        )

        # Sensor quality branch
        self.sensor_encoder = nn.Sequential(
            nn.Linear(6, 32),
            nn.GELU(),
        )

        # Fusion
        self.fusion = nn.Sequential(
            nn.Linear(128 + 64 + 32, 256),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Linear(256, features_dim),
            nn.GELU(),
        )

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        # Nav: [0:18] - pos, vel, att, omega, goal dir, dist
        nav  = self.nav_encoder(obs[:, :18])
        # Obstacles: [18:42] - lidar sectors + nearest obs
        obst = self.obs_encoder(obs[:, 18:42])
        # Sensor: [42:48] - battery, gnss, prev actions
        sens = self.sensor_encoder(obs[:, 42:48])
        fused = torch.cat([nav, obst, sens], dim=-1)
        return self.fusion(fused)


class SB3FeatureExtractor(nn.Module if not _HAS_SB3 else BaseFeaturesExtractor):
    """SB3-compatible wrapper for UAVFeatureExtractor."""

    def __init__(self, observation_space, features_dim: int = 256):
        super().__init__(observation_space, features_dim)
        obs_dim = int(np.prod(observation_space.shape))
        self._extractor = UAVFeatureExtractor(obs_dim, features_dim)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self._extractor(obs)


# ──────────────────────────────────────────────────────────────────────────────
# Transformer Navigation Policy
# ──────────────────────────────────────────────────────────────────────────────

class TransformerNavigationPolicy(nn.Module):
    """
    Transformer-based navigation policy.
    Treats observation tokens as a sequence for attention-based reasoning.

    Inspired by Decision Transformer and GATO architectures.
    """

    def __init__(self, obs_dim: int = 48, action_dim: int = 4,
                 d_model: int = 128, n_heads: int = 4, n_layers: int = 3):
        super().__init__()
        self.obs_dim    = obs_dim
        self.action_dim = action_dim
        self.d_model    = d_model

        # Token embedding: split obs into 8 tokens of 6 dims each
        self.token_dim  = 6
        self.n_tokens   = obs_dim // self.token_dim
        self.embed      = nn.Linear(self.token_dim, d_model)
        self.pos_embed  = nn.Parameter(torch.randn(1, self.n_tokens, d_model) * 0.02)

        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=256,
            dropout=0.1, activation="gelu", batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)

        # Actor head
        self.actor_head = nn.Sequential(
            nn.Linear(d_model, 128),
            nn.GELU(),
            nn.Linear(128, action_dim),
            nn.Tanh(),
        )

        # Critic head
        self.critic_head = nn.Sequential(
            nn.Linear(d_model, 128),
            nn.GELU(),
            nn.Linear(128, 1),
        )

    def forward(self, obs: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        B = obs.shape[0]
        # Reshape to tokens
        tokens = obs.reshape(B, self.n_tokens, self.token_dim)
        x = self.embed(tokens) + self.pos_embed
        x = self.transformer(x)
        # Global average pooling over tokens
        x_pool = x.mean(dim=1)
        action = self.actor_head(x_pool)
        value  = self.critic_head(x_pool)
        return action, value

    def get_action(self, obs: np.ndarray, deterministic: bool = True) -> np.ndarray:
        obs_t = torch.FloatTensor(obs).unsqueeze(0)
        with torch.no_grad():
            action, _ = self.forward(obs_t)
        return action.squeeze(0).numpy()


# ──────────────────────────────────────────────────────────────────────────────
# LSTM Trajectory Forecaster
# ──────────────────────────────────────────────────────────────────────────────

class LSTMTrajectoryForecaster(nn.Module):
    """
    LSTM-based trajectory predictor for dynamic obstacles.
    Input:  sequence of past positions [(x,y,z)] * T
    Output: predicted future positions * H
    """

    def __init__(self, input_dim: int = 3, hidden_dim: int = 64,
                 n_layers: int = 2, horizon: int = 10):
        super().__init__()
        self.horizon    = horizon
        self.hidden_dim = hidden_dim
        self.n_layers   = n_layers

        self.lstm = nn.LSTM(
            input_size=input_dim, hidden_size=hidden_dim,
            num_layers=n_layers, batch_first=True, dropout=0.1
        )
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, 64),
            nn.GELU(),
            nn.Linear(64, input_dim * horizon),
        )

    def forward(self, seq: torch.Tensor) -> torch.Tensor:
        """seq: [B, T, 3] → output: [B, H, 3]"""
        out, _ = self.lstm(seq)
        last    = out[:, -1, :]
        pred    = self.decoder(last)
        return pred.reshape(-1, self.horizon, seq.shape[-1])

    def predict(self, history: np.ndarray) -> np.ndarray:
        """history: [T, 3] → predicted_positions: [H, 3]"""
        seq = torch.FloatTensor(history).unsqueeze(0)
        with torch.no_grad():
            pred = self.forward(seq)
        return pred.squeeze(0).numpy()


# ──────────────────────────────────────────────────────────────────────────────
# Hybrid RL + PID Controller
# ──────────────────────────────────────────────────────────────────────────────

class HybridRLController:
    """
    Blends RL policy output with PID controller using confidence weighting.
    - High RL confidence → use RL action
    - Low RL confidence (near obstacles/boundaries) → fallback to PID
    - Smooth interpolation between them
    """

    def __init__(self, rl_agent, pid_controller, blend_threshold: float = 0.7):
        self._rl      = rl_agent
        self._pid     = pid_controller
        self._thresh  = blend_threshold

    def get_action(self, obs: np.ndarray, pos, vel, att, omega,
                   pos_sp, dt: float) -> np.ndarray:
        # RL action
        rl_action, _ = self._rl.predict(obs, deterministic=True)
        rl_action     = np.clip(rl_action, -1, 1)

        # Confidence: proximity to obstacles (from LiDAR sectors)
        lidar_sectors = obs[18:24]
        min_dist = np.min(lidar_sectors)   # Normalized 0..1
        confidence = np.clip(min_dist * 2.0, 0, 1)  # Full RL if >0.5 clearance

        if confidence >= self._thresh:
            return rl_action

        # PID action
        from navigation.controller import CascadedController
        ctrl = self._pid.update(pos, vel, att, omega, pos_sp, dt=dt)
        pid_action = np.concatenate([
            ctrl.velocity_cmd / 10.0,   # normalize
            [ctrl.yaw_rate_cmd / np.pi]
        ])
        pid_action = np.clip(pid_action, -1, 1)

        # Blend
        alpha = confidence / self._thresh
        return alpha * rl_action + (1.0 - alpha) * pid_action


# ──────────────────────────────────────────────────────────────────────────────
# Training Manager
# ──────────────────────────────────────────────────────────────────────────────

class RLTrainingManager:
    """
    Orchestrates SB3 RL training:
      - Environment wrapping (Monitor, VecNormalize)
      - Callbacks (EvalCallback, CheckpointCallback)
      - Hyperparameter management
      - TensorBoard logging
    """

    ALGORITHMS = {
        "SAC": SAC if _HAS_SB3 else None,
        "PPO": PPO if _HAS_SB3 else None,
        "DQN": DQN if _HAS_SB3 else None,
    }

    def __init__(self, config: dict):
        self._cfg        = config
        rl_cfg           = config.get("rl", {})
        self._algo_name  = rl_cfg.get("algorithm", "SAC")
        self._lr         = rl_cfg.get("learning_rate", 3e-4)
        self._batch_size = rl_cfg.get("batch_size", 256)
        self._buffer_size= rl_cfg.get("buffer_size", 1_000_000)
        self._gamma      = rl_cfg.get("gamma", 0.99)
        train_cfg        = rl_cfg.get("training", {})
        self._total_ts   = train_cfg.get("total_timesteps", 2_000_000)
        self._eval_freq  = train_cfg.get("eval_freq", 10_000)
        self._save_freq  = train_cfg.get("save_freq", 50_000)
        self._ckpt_dir   = Path(train_cfg.get("checkpoint_dir", "models/checkpoints"))
        self._ckpt_dir.mkdir(parents=True, exist_ok=True)
        self._model: Any = None

    def build(self, env) -> Any:
        if not _HAS_SB3:
            raise RuntimeError("stable-baselines3 required for training")

        from envs.uav_env import UAVNavigationEnv

        # Wrap env
        monitor_env = Monitor(env)
        vec_env     = DummyVecEnv([lambda: monitor_env])
        vec_env     = VecNormalize(vec_env, norm_obs=True, norm_reward=True, clip_obs=10.0)

        # Policy kwargs with custom feature extractor
        policy_kwargs = dict(
            features_extractor_class=SB3FeatureExtractor,
            features_extractor_kwargs=dict(features_dim=256),
            net_arch=dict(pi=[256, 256], vf=[256, 256]),
            activation_fn=nn.GELU,
        )

        AlgoClass = self.ALGORITHMS.get(self._algo_name)
        if AlgoClass is None:
            raise ValueError(f"Unknown algorithm: {self._algo_name}")

        common_kwargs = dict(
            policy="MlpPolicy",
            env=vec_env,
            learning_rate=self._lr,
            batch_size=self._batch_size,
            gamma=self._gamma,
            verbose=1,
            tensorboard_log="logs/tensorboard",
            policy_kwargs=policy_kwargs,
        )

        if self._algo_name == "SAC":
            self._model = SAC(
                buffer_size=self._buffer_size,
                tau=0.005,
                ent_coef="auto",
                **common_kwargs
            )
        elif self._algo_name == "PPO":
            self._model = PPO(
                n_steps=2048,
                n_epochs=10,
                clip_range=0.2,
                gae_lambda=0.95,
                **common_kwargs
            )
        elif self._algo_name == "DQN":
            self._model = DQN(
                buffer_size=self._buffer_size,
                exploration_fraction=0.3,
                exploration_final_eps=0.05,
                **common_kwargs
            )

        log.info(f"Built {self._algo_name} agent | lr={self._lr} | batch={self._batch_size}")
        return self._model

    def train(self) -> None:
        if self._model is None:
            raise RuntimeError("Call build() first")

        callbacks = []
        if _HAS_SB3:
            callbacks.append(CheckpointCallback(
                save_freq=self._save_freq,
                save_path=str(self._ckpt_dir),
                name_prefix=f"uav_{self._algo_name.lower()}",
            ))

        log.info(f"Training {self._algo_name} for {self._total_ts:,} timesteps")
        self._model.learn(
            total_timesteps=self._total_ts,
            callback=CallbackList(callbacks) if callbacks else None,
            progress_bar=True,
        )
        self.save("models/final_model")

    def save(self, path: str) -> None:
        if self._model:
            self._model.save(path)
            log.info(f"Model saved: {path}")

    def load(self, path: str, env=None) -> Any:
        if not _HAS_SB3:
            raise RuntimeError("stable-baselines3 required")
        AlgoClass = self.ALGORITHMS.get(self._algo_name)
        self._model = AlgoClass.load(path, env=env)
        log.info(f"Model loaded: {path}")
        return self._model

    @property
    def model(self):
        return self._model
