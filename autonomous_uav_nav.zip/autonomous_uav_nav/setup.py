"""
Autonomous UAV Navigation System
==================================
Setup file for pip install -e .
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

with open("requirements.txt", "r") as f:
    requirements = [
        line.strip() for line in f
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="autonomous-uav-nav",
    version="1.0.0",
    author="UAV Research Team",
    description="Research-grade autonomous UAV navigation using RL, sensor fusion, and computer vision",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.10",
    packages=find_packages(exclude=["tests", "scripts", "docs"]),
    install_requires=requirements,
    extras_require={
        "vision": ["ultralytics>=8.0.0"],
        "gpu":    ["torch>=2.0.0+cu118"],
        "dev":    ["pytest>=7.4.0", "pytest-cov>=4.1.0", "black", "isort", "mypy"],
        "docs":   ["sphinx>=7.0.0", "sphinx-rtd-theme>=1.3.0"],
    },
    entry_points={
        "console_scripts": [
            "uav-sim=scripts.run_simulation:main",
            "uav-train=scripts.train:main",
            "uav-eval=scripts.evaluate:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[
        "UAV", "drone", "autonomous navigation", "reinforcement learning",
        "sensor fusion", "Kalman filter", "path planning", "computer vision",
        "aerospace", "robotics", "swarm intelligence",
    ],
)
